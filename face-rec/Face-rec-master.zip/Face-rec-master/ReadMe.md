## Face Recognition in Javascript using Face-api

code for a medium post

<p align="center">
    <img src="img/money-heist.JPG" />
</p>